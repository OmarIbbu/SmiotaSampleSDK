//
//  SmiotaBLESDK.h
//  SmiotaBLESDK
//
//  Created by Umar Farooq on 17/08/22.
//

#import <Foundation/Foundation.h>

//! Project version number for SmiotaBLESDK.
FOUNDATION_EXPORT double SmiotaBLESDKVersionNumber;

//! Project version string for SmiotaBLESDK.
FOUNDATION_EXPORT const unsigned char SmiotaBLESDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmiotaBLESDK/PublicHeader.h>


